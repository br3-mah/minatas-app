const Zangdar = require('./dist/zangdar.min.js')

module.exports = Zangdar